"""Core utilities and constants"""
